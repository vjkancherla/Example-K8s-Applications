<?php

  header("Location: http://www.evernote.com/\n\n");
  exit();

?>
